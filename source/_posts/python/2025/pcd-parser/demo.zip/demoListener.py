# Generated from ./demo.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .demoParser import demoParser
else:
    from demoParser import demoParser

# This class defines a complete listener for a parse tree produced by demoParser.
class demoListener(ParseTreeListener):

    # Enter a parse tree produced by demoParser#prog.
    def enterProg(self, ctx:demoParser.ProgContext):
        pass

    # Exit a parse tree produced by demoParser#prog.
    def exitProg(self, ctx:demoParser.ProgContext):
        pass


    # Enter a parse tree produced by demoParser#header_line.
    def enterHeader_line(self, ctx:demoParser.Header_lineContext):
        pass

    # Exit a parse tree produced by demoParser#header_line.
    def exitHeader_line(self, ctx:demoParser.Header_lineContext):
        pass


    # Enter a parse tree produced by demoParser#comment.
    def enterComment(self, ctx:demoParser.CommentContext):
        pass

    # Exit a parse tree produced by demoParser#comment.
    def exitComment(self, ctx:demoParser.CommentContext):
        pass


    # Enter a parse tree produced by demoParser#version.
    def enterVersion(self, ctx:demoParser.VersionContext):
        pass

    # Exit a parse tree produced by demoParser#version.
    def exitVersion(self, ctx:demoParser.VersionContext):
        pass


    # Enter a parse tree produced by demoParser#fields.
    def enterFields(self, ctx:demoParser.FieldsContext):
        pass

    # Exit a parse tree produced by demoParser#fields.
    def exitFields(self, ctx:demoParser.FieldsContext):
        pass


    # Enter a parse tree produced by demoParser#size.
    def enterSize(self, ctx:demoParser.SizeContext):
        pass

    # Exit a parse tree produced by demoParser#size.
    def exitSize(self, ctx:demoParser.SizeContext):
        pass


    # Enter a parse tree produced by demoParser#type.
    def enterType(self, ctx:demoParser.TypeContext):
        pass

    # Exit a parse tree produced by demoParser#type.
    def exitType(self, ctx:demoParser.TypeContext):
        pass


    # Enter a parse tree produced by demoParser#count.
    def enterCount(self, ctx:demoParser.CountContext):
        pass

    # Exit a parse tree produced by demoParser#count.
    def exitCount(self, ctx:demoParser.CountContext):
        pass


    # Enter a parse tree produced by demoParser#width.
    def enterWidth(self, ctx:demoParser.WidthContext):
        pass

    # Exit a parse tree produced by demoParser#width.
    def exitWidth(self, ctx:demoParser.WidthContext):
        pass


    # Enter a parse tree produced by demoParser#height.
    def enterHeight(self, ctx:demoParser.HeightContext):
        pass

    # Exit a parse tree produced by demoParser#height.
    def exitHeight(self, ctx:demoParser.HeightContext):
        pass


    # Enter a parse tree produced by demoParser#viewpoint.
    def enterViewpoint(self, ctx:demoParser.ViewpointContext):
        pass

    # Exit a parse tree produced by demoParser#viewpoint.
    def exitViewpoint(self, ctx:demoParser.ViewpointContext):
        pass


    # Enter a parse tree produced by demoParser#points.
    def enterPoints(self, ctx:demoParser.PointsContext):
        pass

    # Exit a parse tree produced by demoParser#points.
    def exitPoints(self, ctx:demoParser.PointsContext):
        pass


    # Enter a parse tree produced by demoParser#data.
    def enterData(self, ctx:demoParser.DataContext):
        pass

    # Exit a parse tree produced by demoParser#data.
    def exitData(self, ctx:demoParser.DataContext):
        pass


    # Enter a parse tree produced by demoParser#data_type.
    def enterData_type(self, ctx:demoParser.Data_typeContext):
        pass

    # Exit a parse tree produced by demoParser#data_type.
    def exitData_type(self, ctx:demoParser.Data_typeContext):
        pass



del demoParser