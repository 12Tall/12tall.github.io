from antlr4 import *
import numpy as np  
from demoLexer import demoLexer  
from demoParser import demoParser  
from demoListener import demoListener  
class Field():
    def __init__(self, name=None,count=None,type=None, size=None):
        self.name = name
        self.count = count
        self.size = size  
        self.type = type

    def __str__(self):
        return f"Field: name={self.name}, type={self.type}, count={self.count}, size={self.size}"

class PCD():
    def __init__(self):
        self.version=0
        self.fields:list[Field]=[]
        self.width=0
        self.height=0
        self.data = None
        self.points = 0
        self.viepoints = []
        self.header_comment = None
        self.offset_line=0  
        self.anounymous_field_index = 0

    def get_dtype_fields(self):
        dtype_fileds=[]
        for f in self.fields:
            if f.name == "_":
                name = f"_{self.anounymous_field_index}"
                self.anounymous_field_index+=1
            else:
                name = f.name
            dtype_fileds.append((name, f'{f.type.lower()}{f.size}', (f.count,)))
        return np.dtype(dtype_fileds)
    def __str__(self):
        return f"""{self.header_comment}
VERSION {self.version}"""

class MyDemoListener(demoListener):
    def __init__(self):
        super().__init__()
        self.offset_line =  0
        self.pcd = PCD()

    def enterProg(self, ctx):
        print("开始解析PCD 文件")
        
    def enterComment(self, ctx):
        self.pcd.header_comment = ctx.COMMENT().getText()
        
    def enterVersion(self, ctx):
        version = ctx.NUMBER().getText()
        self.pcd.version = version

    def enterFields(self, ctx):
        for i, id in enumerate(ctx.ID()):
            name=id.getText()
            if len(self.pcd.fields) <= i:  
                self.pcd.fields.append(Field(name=name))
            else:
                self.pcd.fields[i].name = name
                
    def enterSize(self, ctx):
        for i, token in enumerate(ctx.NUMBER()):
            size=int(token.getText())
            if len(self.pcd.fields) <= i:  
                self.pcd.fields.append(Field(size=size))
            else:
                self.pcd.fields[i].size = size
                
    def enterType(self, ctx):
        for i, token in enumerate(ctx.FIELDTYPE()):
            type=token.getText()
            if len(self.pcd.fields) <= i:  
                self.pcd.fields.append(Field(type=type))
            else:
                self.pcd.fields[i].type = type
  
    def enterCount(self, ctx):
        for i, token in enumerate(ctx.NUMBER()):
            count=int(token.getText())
            if len(self.pcd.fields) <= i:  
                self.pcd.fields.append(Field(count=count))
            else:
                self.pcd.fields[i].count = count

    def enterViewpoint(self, ctx):
        self.pcd.viepoints = [float(v.getText()) for v in ctx.NUMBER()]

    def enterWidth(self, ctx):
        self.pcd.width = int(ctx.NUMBER().getText())

    def enterHeight(self, ctx):
        self.pcd.height = int(ctx.NUMBER().getText())

    def enterPoints(self, ctx):
        self.pcd.points = int(ctx.NUMBER().getText())
    
    def enterData(self, ctx):
        self.pcd.data = ctx.data_type().getText()
    
    def exitProg(self, ctx):
        self.pcd.offset_line =  int(ctx.stop.line)


input_str = """# .PCD v0.7 - Point Cloud Data file format
VERSION 0.7
FIELDS intensity _ x y z _
SIZE 4 1 4 4 4 1
TYPE F U F F F U
COUNT 1 12 1 1 1 4
WIDTH 41305550
HEIGHT 1
VIEWPOINT 0 0 0 0.707107 -0.707107 0 0
POINTS 41305550
DATA binary
"""

def main():
    input_stream = InputStream(input_str)
    lexer = demoLexer(input_stream)
    tokens = CommonTokenStream(lexer)
    parser = demoParser(tokens)

    tree = parser.prog()  # 假设入口规则是 prog
    walker = ParseTreeWalker()
    listener = MyDemoListener()
    walker.walk(listener, tree)
    print("  - 文件头偏移量：", listener.pcd.offset_line)
    # print(tree.toStringTree(recog=parser))

    pcd = listener.pcd
    pcd_dtype = pcd.get_dtype_fields()
    print("  - 数据类型：",pcd_dtype)

    # 读取二进制 
    with open("sampled.pcd", "rb") as f:
        # 跳过 header 行
        for _ in range(pcd.offset_line):
            f.readline()
        
        binary_data = f.read()
        buffer_len = len(binary_data)
        element_size = pcd_dtype.itemsize
        valid_len = (buffer_len // element_size) * element_size
        binary_data = binary_data[:valid_len]
        data = np.frombuffer(binary_data, dtype=pcd_dtype)

    ## 读取ascii
    # data = np.loadtxt("./sampled_ascii.pcd",dtype=pcd.get_dtype_fields(), skiprows=pcd.offset_line )
    print(data)
    print("  - 实际点数量：",data.shape)

if __name__ == '__main__':
    main()