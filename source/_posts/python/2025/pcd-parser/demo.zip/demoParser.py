# Generated from ./demo.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,19,112,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        1,0,4,0,30,8,0,11,0,12,0,31,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
        1,1,1,1,3,1,45,8,1,1,2,1,2,1,2,1,3,1,3,1,3,1,3,1,4,1,4,4,4,56,8,
        4,11,4,12,4,57,1,4,1,4,1,5,1,5,4,5,64,8,5,11,5,12,5,65,1,5,1,5,1,
        6,1,6,4,6,72,8,6,11,6,12,6,73,1,6,1,6,1,7,1,7,4,7,80,8,7,11,7,12,
        7,81,1,7,1,7,1,8,1,8,1,8,1,8,1,9,1,9,1,9,1,9,1,10,1,10,4,10,96,8,
        10,11,10,12,10,97,1,10,1,10,1,11,1,11,1,11,1,11,1,12,1,12,1,12,1,
        12,1,13,1,13,1,13,0,0,14,0,2,4,6,8,10,12,14,16,18,20,22,24,26,0,
        1,1,0,11,13,113,0,29,1,0,0,0,2,44,1,0,0,0,4,46,1,0,0,0,6,49,1,0,
        0,0,8,53,1,0,0,0,10,61,1,0,0,0,12,69,1,0,0,0,14,77,1,0,0,0,16,85,
        1,0,0,0,18,89,1,0,0,0,20,93,1,0,0,0,22,101,1,0,0,0,24,105,1,0,0,
        0,26,109,1,0,0,0,28,30,3,2,1,0,29,28,1,0,0,0,30,31,1,0,0,0,31,29,
        1,0,0,0,31,32,1,0,0,0,32,1,1,0,0,0,33,45,3,4,2,0,34,45,3,6,3,0,35,
        45,3,8,4,0,36,45,3,10,5,0,37,45,3,12,6,0,38,45,3,14,7,0,39,45,3,
        16,8,0,40,45,3,18,9,0,41,45,3,20,10,0,42,45,3,22,11,0,43,45,3,24,
        12,0,44,33,1,0,0,0,44,34,1,0,0,0,44,35,1,0,0,0,44,36,1,0,0,0,44,
        37,1,0,0,0,44,38,1,0,0,0,44,39,1,0,0,0,44,40,1,0,0,0,44,41,1,0,0,
        0,44,42,1,0,0,0,44,43,1,0,0,0,45,3,1,0,0,0,46,47,5,16,0,0,47,48,
        5,18,0,0,48,5,1,0,0,0,49,50,5,1,0,0,50,51,5,17,0,0,51,52,5,18,0,
        0,52,7,1,0,0,0,53,55,5,2,0,0,54,56,5,15,0,0,55,54,1,0,0,0,56,57,
        1,0,0,0,57,55,1,0,0,0,57,58,1,0,0,0,58,59,1,0,0,0,59,60,5,18,0,0,
        60,9,1,0,0,0,61,63,5,3,0,0,62,64,5,17,0,0,63,62,1,0,0,0,64,65,1,
        0,0,0,65,63,1,0,0,0,65,66,1,0,0,0,66,67,1,0,0,0,67,68,5,18,0,0,68,
        11,1,0,0,0,69,71,5,4,0,0,70,72,5,14,0,0,71,70,1,0,0,0,72,73,1,0,
        0,0,73,71,1,0,0,0,73,74,1,0,0,0,74,75,1,0,0,0,75,76,5,18,0,0,76,
        13,1,0,0,0,77,79,5,5,0,0,78,80,5,17,0,0,79,78,1,0,0,0,80,81,1,0,
        0,0,81,79,1,0,0,0,81,82,1,0,0,0,82,83,1,0,0,0,83,84,5,18,0,0,84,
        15,1,0,0,0,85,86,5,6,0,0,86,87,5,17,0,0,87,88,5,18,0,0,88,17,1,0,
        0,0,89,90,5,7,0,0,90,91,5,17,0,0,91,92,5,18,0,0,92,19,1,0,0,0,93,
        95,5,8,0,0,94,96,5,17,0,0,95,94,1,0,0,0,96,97,1,0,0,0,97,95,1,0,
        0,0,97,98,1,0,0,0,98,99,1,0,0,0,99,100,5,18,0,0,100,21,1,0,0,0,101,
        102,5,9,0,0,102,103,5,17,0,0,103,104,5,18,0,0,104,23,1,0,0,0,105,
        106,5,10,0,0,106,107,3,26,13,0,107,108,5,18,0,0,108,25,1,0,0,0,109,
        110,7,0,0,0,110,27,1,0,0,0,7,31,44,57,65,73,81,97
    ]

class demoParser ( Parser ):

    grammarFileName = "demo.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'VERSION'", "'FIELDS'", "'SIZE'", "'TYPE'", 
                     "'COUNT'", "'WIDTH'", "'HEIGHT'", "'VIEWPOINT'", "'POINTS'", 
                     "'DATA'", "'ascii'", "'binary'", "'binary_compressed'" ]

    symbolicNames = [ "<INVALID>", "KEY_VERSION", "KEY_FIELDS", "KEY_SIZE", 
                      "KEY_TYPE", "KEY_COUNT", "KEY_WIDTH", "KEY_HEIGHT", 
                      "KEY_VIEWPOINT", "KEY_POINTS", "KEY_DATA", "ASCII", 
                      "BINARY", "COMPRESSEDBINARY", "FIELDTYPE", "ID", "COMMENT", 
                      "NUMBER", "NEWLINE", "WS" ]

    RULE_prog = 0
    RULE_header_line = 1
    RULE_comment = 2
    RULE_version = 3
    RULE_fields = 4
    RULE_size = 5
    RULE_type = 6
    RULE_count = 7
    RULE_width = 8
    RULE_height = 9
    RULE_viewpoint = 10
    RULE_points = 11
    RULE_data = 12
    RULE_data_type = 13

    ruleNames =  [ "prog", "header_line", "comment", "version", "fields", 
                   "size", "type", "count", "width", "height", "viewpoint", 
                   "points", "data", "data_type" ]

    EOF = Token.EOF
    KEY_VERSION=1
    KEY_FIELDS=2
    KEY_SIZE=3
    KEY_TYPE=4
    KEY_COUNT=5
    KEY_WIDTH=6
    KEY_HEIGHT=7
    KEY_VIEWPOINT=8
    KEY_POINTS=9
    KEY_DATA=10
    ASCII=11
    BINARY=12
    COMPRESSEDBINARY=13
    FIELDTYPE=14
    ID=15
    COMMENT=16
    NUMBER=17
    NEWLINE=18
    WS=19

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def header_line(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(demoParser.Header_lineContext)
            else:
                return self.getTypedRuleContext(demoParser.Header_lineContext,i)


        def getRuleIndex(self):
            return demoParser.RULE_prog

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProg" ):
                listener.enterProg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProg" ):
                listener.exitProg(self)




    def prog(self):

        localctx = demoParser.ProgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_prog)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 29 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 28
                self.header_line()
                self.state = 31 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 67582) != 0)):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Header_lineContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def comment(self):
            return self.getTypedRuleContext(demoParser.CommentContext,0)


        def version(self):
            return self.getTypedRuleContext(demoParser.VersionContext,0)


        def fields(self):
            return self.getTypedRuleContext(demoParser.FieldsContext,0)


        def size(self):
            return self.getTypedRuleContext(demoParser.SizeContext,0)


        def type_(self):
            return self.getTypedRuleContext(demoParser.TypeContext,0)


        def count(self):
            return self.getTypedRuleContext(demoParser.CountContext,0)


        def width(self):
            return self.getTypedRuleContext(demoParser.WidthContext,0)


        def height(self):
            return self.getTypedRuleContext(demoParser.HeightContext,0)


        def viewpoint(self):
            return self.getTypedRuleContext(demoParser.ViewpointContext,0)


        def points(self):
            return self.getTypedRuleContext(demoParser.PointsContext,0)


        def data(self):
            return self.getTypedRuleContext(demoParser.DataContext,0)


        def getRuleIndex(self):
            return demoParser.RULE_header_line

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterHeader_line" ):
                listener.enterHeader_line(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitHeader_line" ):
                listener.exitHeader_line(self)




    def header_line(self):

        localctx = demoParser.Header_lineContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_header_line)
        try:
            self.state = 44
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [16]:
                self.enterOuterAlt(localctx, 1)
                self.state = 33
                self.comment()
                pass
            elif token in [1]:
                self.enterOuterAlt(localctx, 2)
                self.state = 34
                self.version()
                pass
            elif token in [2]:
                self.enterOuterAlt(localctx, 3)
                self.state = 35
                self.fields()
                pass
            elif token in [3]:
                self.enterOuterAlt(localctx, 4)
                self.state = 36
                self.size()
                pass
            elif token in [4]:
                self.enterOuterAlt(localctx, 5)
                self.state = 37
                self.type_()
                pass
            elif token in [5]:
                self.enterOuterAlt(localctx, 6)
                self.state = 38
                self.count()
                pass
            elif token in [6]:
                self.enterOuterAlt(localctx, 7)
                self.state = 39
                self.width()
                pass
            elif token in [7]:
                self.enterOuterAlt(localctx, 8)
                self.state = 40
                self.height()
                pass
            elif token in [8]:
                self.enterOuterAlt(localctx, 9)
                self.state = 41
                self.viewpoint()
                pass
            elif token in [9]:
                self.enterOuterAlt(localctx, 10)
                self.state = 42
                self.points()
                pass
            elif token in [10]:
                self.enterOuterAlt(localctx, 11)
                self.state = 43
                self.data()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CommentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def COMMENT(self):
            return self.getToken(demoParser.COMMENT, 0)

        def NEWLINE(self):
            return self.getToken(demoParser.NEWLINE, 0)

        def getRuleIndex(self):
            return demoParser.RULE_comment

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComment" ):
                listener.enterComment(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComment" ):
                listener.exitComment(self)




    def comment(self):

        localctx = demoParser.CommentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_comment)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 46
            self.match(demoParser.COMMENT)
            self.state = 47
            self.match(demoParser.NEWLINE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class VersionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def KEY_VERSION(self):
            return self.getToken(demoParser.KEY_VERSION, 0)

        def NUMBER(self):
            return self.getToken(demoParser.NUMBER, 0)

        def NEWLINE(self):
            return self.getToken(demoParser.NEWLINE, 0)

        def getRuleIndex(self):
            return demoParser.RULE_version

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVersion" ):
                listener.enterVersion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVersion" ):
                listener.exitVersion(self)




    def version(self):

        localctx = demoParser.VersionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_version)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 49
            self.match(demoParser.KEY_VERSION)
            self.state = 50
            self.match(demoParser.NUMBER)
            self.state = 51
            self.match(demoParser.NEWLINE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FieldsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def KEY_FIELDS(self):
            return self.getToken(demoParser.KEY_FIELDS, 0)

        def NEWLINE(self):
            return self.getToken(demoParser.NEWLINE, 0)

        def ID(self, i:int=None):
            if i is None:
                return self.getTokens(demoParser.ID)
            else:
                return self.getToken(demoParser.ID, i)

        def getRuleIndex(self):
            return demoParser.RULE_fields

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFields" ):
                listener.enterFields(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFields" ):
                listener.exitFields(self)




    def fields(self):

        localctx = demoParser.FieldsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_fields)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 53
            self.match(demoParser.KEY_FIELDS)
            self.state = 55 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 54
                self.match(demoParser.ID)
                self.state = 57 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==15):
                    break

            self.state = 59
            self.match(demoParser.NEWLINE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SizeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def KEY_SIZE(self):
            return self.getToken(demoParser.KEY_SIZE, 0)

        def NEWLINE(self):
            return self.getToken(demoParser.NEWLINE, 0)

        def NUMBER(self, i:int=None):
            if i is None:
                return self.getTokens(demoParser.NUMBER)
            else:
                return self.getToken(demoParser.NUMBER, i)

        def getRuleIndex(self):
            return demoParser.RULE_size

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSize" ):
                listener.enterSize(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSize" ):
                listener.exitSize(self)




    def size(self):

        localctx = demoParser.SizeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_size)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 61
            self.match(demoParser.KEY_SIZE)
            self.state = 63 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 62
                self.match(demoParser.NUMBER)
                self.state = 65 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==17):
                    break

            self.state = 67
            self.match(demoParser.NEWLINE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def KEY_TYPE(self):
            return self.getToken(demoParser.KEY_TYPE, 0)

        def NEWLINE(self):
            return self.getToken(demoParser.NEWLINE, 0)

        def FIELDTYPE(self, i:int=None):
            if i is None:
                return self.getTokens(demoParser.FIELDTYPE)
            else:
                return self.getToken(demoParser.FIELDTYPE, i)

        def getRuleIndex(self):
            return demoParser.RULE_type

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterType" ):
                listener.enterType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitType" ):
                listener.exitType(self)




    def type_(self):

        localctx = demoParser.TypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_type)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 69
            self.match(demoParser.KEY_TYPE)
            self.state = 71 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 70
                self.match(demoParser.FIELDTYPE)
                self.state = 73 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==14):
                    break

            self.state = 75
            self.match(demoParser.NEWLINE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CountContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def KEY_COUNT(self):
            return self.getToken(demoParser.KEY_COUNT, 0)

        def NEWLINE(self):
            return self.getToken(demoParser.NEWLINE, 0)

        def NUMBER(self, i:int=None):
            if i is None:
                return self.getTokens(demoParser.NUMBER)
            else:
                return self.getToken(demoParser.NUMBER, i)

        def getRuleIndex(self):
            return demoParser.RULE_count

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCount" ):
                listener.enterCount(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCount" ):
                listener.exitCount(self)




    def count(self):

        localctx = demoParser.CountContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_count)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 77
            self.match(demoParser.KEY_COUNT)
            self.state = 79 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 78
                self.match(demoParser.NUMBER)
                self.state = 81 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==17):
                    break

            self.state = 83
            self.match(demoParser.NEWLINE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class WidthContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def KEY_WIDTH(self):
            return self.getToken(demoParser.KEY_WIDTH, 0)

        def NUMBER(self):
            return self.getToken(demoParser.NUMBER, 0)

        def NEWLINE(self):
            return self.getToken(demoParser.NEWLINE, 0)

        def getRuleIndex(self):
            return demoParser.RULE_width

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterWidth" ):
                listener.enterWidth(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitWidth" ):
                listener.exitWidth(self)




    def width(self):

        localctx = demoParser.WidthContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_width)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 85
            self.match(demoParser.KEY_WIDTH)
            self.state = 86
            self.match(demoParser.NUMBER)
            self.state = 87
            self.match(demoParser.NEWLINE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class HeightContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def KEY_HEIGHT(self):
            return self.getToken(demoParser.KEY_HEIGHT, 0)

        def NUMBER(self):
            return self.getToken(demoParser.NUMBER, 0)

        def NEWLINE(self):
            return self.getToken(demoParser.NEWLINE, 0)

        def getRuleIndex(self):
            return demoParser.RULE_height

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterHeight" ):
                listener.enterHeight(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitHeight" ):
                listener.exitHeight(self)




    def height(self):

        localctx = demoParser.HeightContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_height)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 89
            self.match(demoParser.KEY_HEIGHT)
            self.state = 90
            self.match(demoParser.NUMBER)
            self.state = 91
            self.match(demoParser.NEWLINE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ViewpointContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def KEY_VIEWPOINT(self):
            return self.getToken(demoParser.KEY_VIEWPOINT, 0)

        def NEWLINE(self):
            return self.getToken(demoParser.NEWLINE, 0)

        def NUMBER(self, i:int=None):
            if i is None:
                return self.getTokens(demoParser.NUMBER)
            else:
                return self.getToken(demoParser.NUMBER, i)

        def getRuleIndex(self):
            return demoParser.RULE_viewpoint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterViewpoint" ):
                listener.enterViewpoint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitViewpoint" ):
                listener.exitViewpoint(self)




    def viewpoint(self):

        localctx = demoParser.ViewpointContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_viewpoint)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 93
            self.match(demoParser.KEY_VIEWPOINT)
            self.state = 95 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 94
                self.match(demoParser.NUMBER)
                self.state = 97 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==17):
                    break

            self.state = 99
            self.match(demoParser.NEWLINE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PointsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def KEY_POINTS(self):
            return self.getToken(demoParser.KEY_POINTS, 0)

        def NUMBER(self):
            return self.getToken(demoParser.NUMBER, 0)

        def NEWLINE(self):
            return self.getToken(demoParser.NEWLINE, 0)

        def getRuleIndex(self):
            return demoParser.RULE_points

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPoints" ):
                listener.enterPoints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPoints" ):
                listener.exitPoints(self)




    def points(self):

        localctx = demoParser.PointsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_points)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 101
            self.match(demoParser.KEY_POINTS)
            self.state = 102
            self.match(demoParser.NUMBER)
            self.state = 103
            self.match(demoParser.NEWLINE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DataContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def KEY_DATA(self):
            return self.getToken(demoParser.KEY_DATA, 0)

        def data_type(self):
            return self.getTypedRuleContext(demoParser.Data_typeContext,0)


        def NEWLINE(self):
            return self.getToken(demoParser.NEWLINE, 0)

        def getRuleIndex(self):
            return demoParser.RULE_data

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterData" ):
                listener.enterData(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitData" ):
                listener.exitData(self)




    def data(self):

        localctx = demoParser.DataContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_data)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 105
            self.match(demoParser.KEY_DATA)
            self.state = 106
            self.data_type()
            self.state = 107
            self.match(demoParser.NEWLINE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Data_typeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ASCII(self):
            return self.getToken(demoParser.ASCII, 0)

        def BINARY(self):
            return self.getToken(demoParser.BINARY, 0)

        def COMPRESSEDBINARY(self):
            return self.getToken(demoParser.COMPRESSEDBINARY, 0)

        def getRuleIndex(self):
            return demoParser.RULE_data_type

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterData_type" ):
                listener.enterData_type(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitData_type" ):
                listener.exitData_type(self)




    def data_type(self):

        localctx = demoParser.Data_typeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_data_type)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 109
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 14336) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





